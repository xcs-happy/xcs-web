<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'xcs' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '>X+?aH}Y@6sNGCHdcC2<cU=L]U[2hq6K(Kh{:qz-uR]u#C>UNDvf4E9~$c#Yo2uB' );
define( 'SECURE_AUTH_KEY',  '[U2fpb5^$Es<5F3mq!=S]<sb#[2BN@8D6R(Xc0 vvP.B[5~*h:kG4rI$6tc@#PI<' );
define( 'LOGGED_IN_KEY',    ';hxdfDD=|dhhbt6+JIH5g/neBV@2%6Jat4qY_/=DrOlj{NbLm20ug}GJ{J&gU`mR' );
define( 'NONCE_KEY',        '[K(hR*`V|,t<yr%=U>=|0<0tTS3T]^M]jalIWvDBKu_&7*Kh=$LBs}<Rj!^I-;0Y' );
define( 'AUTH_SALT',        '~] _F l.$c:j]biDcbNA1+8/uHCLmtC*~gc qNpg# f?P<W{xAMmOoi*lBm7A?@Z' );
define( 'SECURE_AUTH_SALT', '1nNqkgUZi_]kb=uhS%3*|npQ~QAH%-m*sm|;y~OLmRiWyWr=.<*ymYUe&%?&8,0F' );
define( 'LOGGED_IN_SALT',   'p~5#|4{J}<*[wHB*J}#:ua*@N-c6A[r1^X~UCcoB5&X?yBU g_358.S.i6AyH;oM' );
define( 'NONCE_SALT',       '8Ezwm*+dIJUkK0qu!.zMKA$>hRYZ19=+X!enW7[l|;C8Rp%hF8c9{/=bRzx:]G7>' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
